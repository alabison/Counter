let counter=document.getElementById("cou");
let save=document.getElementById("ss");
let count=0;


function increment(){
count+=1;
counter.innerText=count;

}

function decrement(){
    count-=1;
    counter.innerText=count;
    
    }
function saver(){
//let countStr=count +  "-";
let countStr=count;
save.textContent=countStr;

}

function reset(){
    count-=count;
    counter.innerText=count;
    saver();
    
    }
    